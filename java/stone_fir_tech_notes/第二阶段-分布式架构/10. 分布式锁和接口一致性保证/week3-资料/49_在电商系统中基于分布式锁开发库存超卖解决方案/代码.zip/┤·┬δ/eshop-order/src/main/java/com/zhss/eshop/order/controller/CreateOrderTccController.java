package com.zhss.eshop.order.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.recipes.locks.InterProcessLock;
import org.apache.curator.framework.recipes.locks.InterProcessMultiLock;
import org.apache.curator.framework.recipes.locks.InterProcessMutex;
import org.bytesoft.bytetcc.supports.spring.aware.CompensableContextAware;
import org.bytesoft.compensable.Compensable;
import org.bytesoft.compensable.CompensableCancel;
import org.bytesoft.compensable.CompensableConfirm;
import org.bytesoft.compensable.CompensableContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.zhss.eshop.common.util.CloneDirection;
import com.zhss.eshop.order.api.InventoryTccService;
import com.zhss.eshop.order.curator.CuratorClient;
import com.zhss.eshop.order.domain.OrderInfoDTO;
import com.zhss.eshop.order.domain.OrderInfoVO;
import com.zhss.eshop.order.domain.OrderItemDTO;
import com.zhss.eshop.order.mapper.UniqueRecordMapper;
import com.zhss.eshop.order.service.OrderCreateApi;
import com.zhss.eshop.order.service.OrderInfoService;
import com.zhss.eshop.order.state.LoggedOrderStateManager;

@RestController
@RequestMapping("/order/create")  
@Compensable(interfaceClass = OrderCreateApi.class, simplified = true)
public class CreateOrderTccController implements OrderCreateApi, CompensableContextAware {
	
	/**
	 * 订单管理service组件
	 */
	@Autowired
	private OrderInfoService orderInfoService;
	/**
	 * 库存服务
	 */
	@Autowired
	private InventoryTccService inventoryTccService;
	/**
	 * 订单状态管理器
	 */
	@Autowired
	private LoggedOrderStateManager orderStateManager;
	/**
	 * tcc事务上下文
	 */
	private CompensableContext aware;
	@Autowired
	private UniqueRecordMapper uniqueRecordMapper;
	
	/**
	 * 新建订单
	 * @param order
	 * @return
	 */
	@PostMapping("/{requestId}")  
	@Transactional
	public OrderInfoVO save(@RequestBody OrderInfoVO orderVO,  
			@PathVariable("requestId") String requesetId) throws Exception {
		uniqueRecordMapper.insert("CreateOrderTccController_save_" + requesetId); 
		
		OrderInfoDTO order = orderVO.clone(OrderInfoDTO.class, CloneDirection.FORWARD);
		
		if(order.getCouponId() == null) {
			order.setCouponId(-1L); 
		}
		
		// 相当于是得在这里，先对这个订单中所有的商品加上一个分布式锁
		// 这里是不是就可以用到之前我们学习到的那个MultiLock的概念了，一次性可以拿多把锁
		// 就是说一次性要锁掉多个资源
		CuratorFramework curatorClient = CuratorClient.getInstance();
		
		List<InterProcessLock> locks = new ArrayList<InterProcessLock>();
		for(OrderItemDTO orderItem : order.getOrderItems()) {
			InterProcessLock lock = new InterProcessMutex(curatorClient, 
					"/locks/stock_lock_" + orderItem.getGoodsSkuId()); 
			locks.add(lock);
		}
		
		InterProcessMultiLock multiLock = new InterProcessMultiLock(locks);
		multiLock.acquire();
		
		// 本来这里应该是要依赖库存服务，查询订单中每个商品的库存，确认说商品的库存是充足的
		// 但是这行代码让我给删掉了
		// for(OrderItemDTO orderItem : order.getOrderItems) {
		// 		Long saleStockQuantity = inventoryService.getSaleStockQuantity(orderItem.getGoodsSkuId);
		// 		if(orderItem.getPurchaseQuantity() > saleStockQuantity) {
		//			return false;
		//		}
		// }
		
		OrderInfoDTO resultOrder = orderInfoService.save(order);
		aware.setVariable("orderJSON", JSONObject.toJSONString(resultOrder));    
		inventoryTccService.informSubmitOrderEvent(resultOrder); 
		
		multiLock.release();
		
		return resultOrder.clone(OrderInfoVO.class, CloneDirection.OPPOSITE);
	}
	
	@CompensableConfirm
	@Transactional
	public void confirmSave(OrderInfoVO orderVO, String requestId) throws Exception {
		String orderJSON = (String) aware.getVariable("orderJSON");
		OrderInfoDTO order = JSONObject.parseObject(orderJSON, OrderInfoDTO.class);  
		orderStateManager.create(order); 
	}
	
	@CompensableCancel
	@Transactional
	public void cancelSave(OrderInfoVO orderVO, String requestId) throws Exception {
		String orderJSON = (String) aware.getVariable("orderJSON");
		OrderInfoDTO order = JSONObject.parseObject(orderJSON, OrderInfoDTO.class);  
		orderStateManager.cancel(order);  
	}

	@Override
	public void setCompensableContext(CompensableContext aware) {
		this.aware = aware;
	}
	
}
