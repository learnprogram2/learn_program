package com.zhss.eshop.order.service;

public interface OrderPayApi {
	
	Boolean informPayOrderSuccessed(Long orderInfoId) throws Exception;
	
}
