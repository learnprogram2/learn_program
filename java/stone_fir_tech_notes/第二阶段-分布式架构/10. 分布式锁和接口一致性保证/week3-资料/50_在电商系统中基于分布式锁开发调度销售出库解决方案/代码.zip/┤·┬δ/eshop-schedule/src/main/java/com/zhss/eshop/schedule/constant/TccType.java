package com.zhss.eshop.schedule.constant;

public class TccType {
	
	public static final Integer TRY = 1;
	public static final Integer CONFIRM = 2;
	public static final Integer CANCEL = 3;
	
	private TccType() {
		
	}
	
}
