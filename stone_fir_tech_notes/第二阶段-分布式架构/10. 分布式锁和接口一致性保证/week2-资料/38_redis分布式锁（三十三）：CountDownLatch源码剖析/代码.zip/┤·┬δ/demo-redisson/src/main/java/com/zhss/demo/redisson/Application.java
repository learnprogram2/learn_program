package com.zhss.demo.redisson;

import java.util.Date;

import org.redisson.Redisson;
import org.redisson.api.RCountDownLatch;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;

public class Application {

	public static void main(String[] args) throws Exception {
		// 这个Config的源码不用去看了，里面就是封装了一些配置
		Config config = new Config();
		config.useClusterServers()
		    .addNodeAddress("redis://192.168.31.114:7001")
		    .addNodeAddress("redis://192.168.31.114:7002")
		    .addNodeAddress("redis://192.168.31.114:7003")
		    .addNodeAddress("redis://192.168.31.184:7001")
		    .addNodeAddress("redis://192.168.31.184:7002")
		    .addNodeAddress("redis://192.168.31.184:7003");
		// RedissonClient创建过程的源码，也不用去看了，这个里面就是跟redis建立一些连接
		RedissonClient redisson = Redisson.create(config);
		
		
//		RLock lock = redisson.getLock("anyLock");
//		
//		lock.lock();
//		Thread.sleep(10000);  
//		
//		lock.lock();
//		Thread.sleep(10000);  
//		lock.unlock(); 
//		
//		Thread.sleep(10000);  
//		lock.unlock();
//		
//		boolean res = lock.tryLock(100, 10, TimeUnit.SECONDS);
//		// 返回一个尝试获取锁的一个结果，是否成功获取到锁
//		System.out.println(res);  
		
//		RLock fairLock = redisson.getFairLock("anyLock"); 
//		fairLock.lock();
//		fairLock.unlock();
		
//		RLock lock1 = redisson.getLock("lock1");
//		RLock lock2 = redisson.getLock("lock2");
//		RLock lock3 = redisson.getLock("lock3");

//		RedissonMultiLock lock = new RedissonMultiLock(lock1, lock2, lock3);
//		RedissonRedLock lock = new RedissonRedLock(lock1, lock2, lock3);
//		lock.lock();
//		lock.unlock();
		
//		RReadWriteLock rwlock = redisson.getReadWriteLock("anyLock");
//		rwlock.readLock().lock();
//		rwlock.readLock().unlock();
//		rwlock.writeLock().lock();
//		rwlock.writeLock().unlock();
		
//		RSemaphore semaphore = redisson.getSemaphore("semaphore");
//		semaphore.trySetPermits(3);
//		
//		for(int i = 0; i < 10; i++) {
//			new Thread(new Runnable() {
//
//				@Override
//				public void run() {
//					try {
//						System.out.println(new Date() + "：线程[" + Thread.currentThread().getName() + "]尝试获取Semaphore锁"); 
//						semaphore.acquire();
//						System.out.println(new Date() + "：线程[" + Thread.currentThread().getName() + "]成功获取到了Semaphore锁，开始工作"); 
//						Thread.sleep(3000);  
//						semaphore.release();
//						System.out.println(new Date() + "：线程[" + Thread.currentThread().getName() + "]释放Semaphore锁"); 
//					} catch (Exception e) {
//						e.printStackTrace();
//					}
//				}
//				
//			}).start();
//		}
		
		RCountDownLatch latch = redisson.getCountDownLatch("anyCountDownLatch");
		latch.trySetCount(3);
		System.out.println(new Date() + "：线程[" + Thread.currentThread().getName() + "]设置了必须有3个线程执行countDown，进入等待中。。。"); 
		
		for(int i = 0; i < 3; i++) {
			new Thread(new Runnable() {

				@Override
				public void run() {
					try {
						System.out.println(new Date() + "：线程[" + Thread.currentThread().getName() + "]在做一些操作，请耐心等待。。。。。。"); 
						Thread.sleep(3000); 
						RCountDownLatch localLatch = redisson.getCountDownLatch("anyCountDownLatch");
						localLatch.countDown();
						System.out.println(new Date() + "：线程[" + Thread.currentThread().getName() + "]执行countDown操作"); 
					} catch (Exception e) {
						e.printStackTrace(); 
					}
				}
				
			}).start();
		}
		
		latch.await();
		System.out.println(new Date() + "：线程[" + Thread.currentThread().getName() + "]收到通知，有3个线程都执行了countDown操作，可以继续往下走"); 
	}
	
}
